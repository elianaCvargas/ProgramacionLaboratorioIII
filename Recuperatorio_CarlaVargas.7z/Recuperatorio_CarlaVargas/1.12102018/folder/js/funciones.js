
var idActual = 0;
window.onload = function () {
    xml.onreadystatechange = getPagina;
    xml.open("GET", "http://localhost:3000/personas", true);

    xml.send(null);
    ocultarFormulario();
    

}


function getPagina() {
    if (xml.readyState == 4) {
        if (xml.status == 200) {
            var personas = JSON.parse(xml.responseText);
            var tablaPersonas = document.getElementById("tablaPersonas");
            tablaPersonas.innerHTML;
            for (var i = 0; i < personas.length; i++) {
                var id = personas[i].id;
                var foto = "<tr><td id = \"foto_" + id + "\" onClick=\"adjuntarImagen(" + id + ")\">" + "<img src=\"" + personas[i].foto.data + "\">"+   "</td>";
                var nombre = "<tr><td id = \"nombre_" + id + "\" ondblclick=\"abrirFormulario(" + id + ")\">" + personas[i].nombre.toString() + "</td>";
                var apellido = "<td id = \"apellido_" + id + "\">" + personas[i].apellido.toString() + "</td>";
                var fecha = "<td id = \"fecha_" + id + "\">" + personas[i].fecha.toString() + "</td>";
                var sexo = "<td id = \"sexo_" + id + "\">" + personas[i].sexo.toString() + "</td></tr>";
                tablaPersonas.innerHTML += nombre + apellido + fecha + sexo;
            }

        }
    }
}

function ocultarFormulario(obj) {
    $("#boxData").hide();
    $("#nombreRequerido").hide();
    $("#apellidoRequerido").hide();
    $("#nombreCorto").hide();
    $("#apellidoCorto").hide();
    $("#loader").hide();
    $("#fechaMenor").hide();
}

function abrirFormulario(indice) {

    var nombre = document.getElementById("nombre_" + indice).innerText;
    var apellido = document.getElementById("apellido_" + indice).innerText;
    var fecha = document.getElementById("fecha_" + indice).innerText;
    var sexo = document.getElementById("sexo_" + indice).innerText;
    var nombreIn = document.getElementById("txtNombre");
    nombreIn.value = nombre;
    var apellidoIn = document.getElementById("txtApellido");
    apellidoIn.value = apellido;
    var fechaIn = document.getElementById("txtFecha");
    fechaIn.value = fecha;
    var sexoMRb = document.getElementById("txtSexoM");
    var sexoFRb = document.getElementById("txtSexoF");
    if (sexo == "Female") {
        sexoFRb.checked = "true";
    }
    else {
        sexoMRb.checked = "true";
    }
    idActual = indice;
    document.getElementById("boxData").style.display = "block";
}



function modificarDatos() {

    if (validar()) {

        var nombreIn = document.getElementById("txtNombre");
        var apellidoIn = document.getElementById("txtApellido");
        var fechaIn = document.getElementById("txtFecha");
        var sexoMRb = document.getElementById("txtSexoM");
        var sexoFRb = document.getElementById("txtSexoF");

        var nombreP = nombreIn.value;
        var apellidoP = apellidoIn.value;

        
            var fechaP = fechaIn.value;

        

        


        if (sexoMRb.checked) {

            var sexoP = sexoMRb.value;
        }
        else {
            var sexoP = sexoFRb.value;
        }
        var persona =
        {
            nombre: nombreP,
            apellido: apellidoP,
            fecha: fechaP,
            sexo: sexoP,
            id: idActual
        };

        enviarDatosPOST("editar", persona);

        $("#loader").show(); 
        $("#boxData").addClass("edit");
    }

}

function eliminarDatos() {
    var respuesta = confirm("Seguro que desea eliminar este registro?");
    var id = {
        "id": idActual
    };
    if (respuesta) {
        enviarDatosPOST("eliminar", id);
    }


}


function agregarId()
{
    g = document.createElement('div');
    g.setAttribute("id", "Div1");
}

function adjuntarImagen(id)
{
    alert("Falta!");

}

