var xml = new XMLHttpRequest();
var server = "http://localhost:3000/";

function functionCallBackPost() {
    if (xml.readyState == 4) {
        if (xml.status == 200) {
            console.log("Response: " + xml.responseText);
            var data = JSON.parse(xml.responseText);
           location.reload();
           
            
        }
        else
            alert("Error Servidor - Codigo: " + xml.status);
    }
}
function enviarDatosPOST(path, obj) {
    xml.onreadystatechange = functionCallBackPost;
    xml.open("POST", server + path, true);
    xml.setRequestHeader("Content-Type", "application/json");
    xml.send(JSON.stringify(obj));
}