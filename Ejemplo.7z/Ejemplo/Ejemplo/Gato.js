///<reference path="./Animal.ts" />
var Mascota;
(function (Mascota) {
    var Gato = /** @class */ (function () {
        function Gato(nombre) {
            this.nombre = nombre;
        }
        Gato.prototype.hacerRuido = function () {
            console.log("miau!!!");
        };
        Gato.prototype.toJson = function () {
            var animal = {
                nombre: this.nombre,
                tipo: 'gato'
            };
            return animal;
        };
        return Gato;
    }());
    Mascota.Gato = Gato;
})(Mascota || (Mascota = {}));
