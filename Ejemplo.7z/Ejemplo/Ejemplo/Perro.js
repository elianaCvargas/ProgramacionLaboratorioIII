///<reference path="./Animal.ts" />
var Mascota;
(function (Mascota) {
    var Perro = /** @class */ (function () {
        function Perro(nombre) {
            this.nombre = nombre;
        }
        Perro.prototype.hacerRuido = function () {
            console.log("guau!!!");
        };
        Perro.prototype.toJson = function () {
            var animal = {
                nombre: this.nombre,
                tipo: 'perro'
            };
            return animal;
        };
        return Perro;
    }());
    Mascota.Perro = Perro;
})(Mascota || (Mascota = {}));
