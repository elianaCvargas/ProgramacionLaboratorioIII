namespace Mascota{
    export interface Animal{//export hace que la interface sea visible desde afuera
        nombre:string;
        hacerRuido():void;


        toJson():object;


    }
}
//funcion  tojson() que devuelva el  string en  form json
