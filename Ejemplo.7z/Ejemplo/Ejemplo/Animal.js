//funcion  tojson() que devuelva el  string en  form json
