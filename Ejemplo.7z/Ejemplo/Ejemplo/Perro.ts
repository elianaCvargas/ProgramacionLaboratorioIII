///<reference path="./Animal.ts" />
namespace Mascota
{
    export class Perro implements Animal{
        nombre:string;
        constructor(nombre:string){
            this.nombre=nombre;
        }
        hacerRuido():void{
            console.log("guau!!!");
        }
        toJson():object{
            var animal{
                nombre: this.nombre,
                tipo: 'perro'
            } 
            return animal;
        }
    }
}

