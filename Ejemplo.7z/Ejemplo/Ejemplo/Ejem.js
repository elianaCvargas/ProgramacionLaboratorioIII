/// <reference path="./Animal.ts" />
/// <reference path="./Perro.ts" />
/// <reference path="./Gato.ts" />
var Ejemplo;
(function (Ejemplo) {
    var Programa = /** @class */ (function () {
        function Programa() {
        }
        //function hablar(a:Animal){ function cuando esta dentro de la clase no es necesario 
        Programa.hablar = function (a) {
            console.log(a.nombre);
            a.hacerRuido();
        };
        Programa.accionar = function () {
            var perro = new Mascota.Perro("Timmy");
            var gato = new Mascota.Gato("Michi");
            var animales = new Array();
            animales.push(perro);
            animales.push(gato);
            animales.forEach(Programa.hablar);
        };
        Programa.crearMascota = function (nombre) {
            var isDog = '';
            if ($("#dog").is(":checked")) {
                var perro = new Mascota.Perro(nombre);
                Programa.animales.push(perro);
                // Programa.animales.forEach(Programa.hablar);
                isDog = $("#dog").val();
            }
            else {
                var gato = new Mascota.Gato(nombre);
                Programa.animales.push(gato);
                isDog = $("#cat").val();
            }
            var name = $("#animal").val();
            var animal = Programa.convertirJson(Programa.animales, isDog);
            var myJSON = JSON.stringify(animal);
            // console.log(animal.nombre);
            // console.log(Programa.animales);
            // alert(Programa.animales.toString());
            // localStorage.setItem("animales", myJSON);
        };
        Programa.convertirJson = function (animales, tipo) {
            var i = 0;
            Programa.animales.forEach(function (element) {
                console.log(element);
                element.toJson();
            });
        };
        Programa.animales = new Array();
        return Programa;
    }());
    Ejemplo.Programa = Programa;
})(Ejemplo || (Ejemplo = {}));
