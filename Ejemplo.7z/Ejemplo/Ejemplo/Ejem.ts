/// <reference path="./Animal.ts" />
/// <reference path="./Perro.ts" />
/// <reference path="./Gato.ts" />
namespace Ejemplo{
 export class Programa{
    
    static animales = new Array<Mascota.Animal>();

    //function hablar(a:Animal){ function cuando esta dentro de la clase no es necesario 
    static hablar(a:Mascota.Animal){
        console.log(a.nombre);
        a.hacerRuido();
    }

    static accionar()
    {
        var perro = new Mascota.Perro("Timmy");
        var gato = new Mascota.Gato("Michi");

        var animales = new Array<Mascota.Animal>();
        animales.push(perro);
        animales.push(gato);
        animales.forEach(Programa.hablar);
    
    }
    
    static crearMascota(nombre:string)
    { 
        var isDog = '';
        
        if($("#dog").is(":checked"))
        {            
            var perro:Mascota.Perro = new Mascota.Perro(nombre);           
            Programa.animales.push(perro);
           // Programa.animales.forEach(Programa.hablar);
            isDog = $("#dog").val();
            

        }
        else
        {
            var gato:Mascota.Gato = new Mascota.Gato(nombre);
            Programa.animales.push(gato);
            isDog = $("#cat").val();
        }
    
        var name = $("#animal").val();
        
       var animal =  Programa.convertirJson(Programa.animales, isDog);
        var myJSON = JSON.stringify(animal);

        // console.log(animal.nombre);
        // console.log(Programa.animales);
        // alert(Programa.animales.toString());
        // localStorage.setItem("animales", myJSON);
    }

    static convertirJson(animales:Array<Mascota.Animal>, tipo)
    {
        var i = 0;
        Programa.animales.forEach(function(element) {
            console.log(element);
            element.toJson();
            
          });
    }


    
//para que me reconozca el jquery 
//1. npm en el  git: npm install @types/jquery
//2. <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> en  el  html
/*
    localStorage.setItem(clave, valor);
    window.location.href="ruta"
    tsc *.ts -w--> PARA TRASPILAR
    tsc  --init--> instalar la config de tsc y  poder descomentar la parte que te permite debuguear

    guardar la lista de animales en el local storage (el  local storage solo guarda strings (deberemos convertir))
    hacer un  abm con una lista de todos los animales. usar  boostrap. todo con  el  local  storage

    crear una lista utilizar el reduce,  map 
    hacer filtros

    como hacer un  modal con boostrap (para el popup de la tabla)
*/ 
 }

}

