/// <reference path="./Animal.ts" />
/// <reference path="./Perro.ts" />
/// <reference path="./Gato.ts" />
namespace Ejemplo{
 export class Programa{
    
    //function hablar(a:Animal){ function cuando esta dentro de la clase no es necesario 
    static hablar(a:Mascota.Animal){
        console.log(a.nombre);
        a.hacerRuido();
    }

    static accionar()
    {
        var perro = new Mascota.Perro("Timmy");
        var gato = new Mascota.Gato("Michi");

        var animales = new Array<Mascota.Animal>();
        animales.push(perro);
        animales.push(gato);
        animales.forEach(Programa.hablar);
    
    }
    
    static crearMascota()
    {
        
        if($("#dog").is(":checked"))
        {
            alert("checked");
        }

    }

    


    
//para que me reconozca el jquery 
//1. npm en el  git: npm install @types/jquery
//2. <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> en  el  html
/*
    localStorage.setItem(clave, valor);
    window.location.href="ruta"
    tsc *.ts -w--> PARA TRASPILAR
    tsc  --init--> instalar la config de tsc y  poder descomentar la parte que te permite debuguear

    guardar la lista de animales en el local storage (el  local storage solo guarda strings (deberemos convertir))
    hacer un  abm con una lista de todos los animales. usar  boostrap. todo con  el  local  storage
*/ 
 }

}

