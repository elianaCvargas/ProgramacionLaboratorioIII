///<reference path="./Animal.ts" />
namespace Mascota{
    export class Gato implements Animal{
        nombre:string;
        constructor(nombre:string){
            this.nombre=nombre;
        }
        hacerRuido():void{
            console.log("miau!!!");
        }
    }

}


