namespace Mascota{
    export interface Animal{//export hace que la interface sea visible desde afuera
        nombre:string;
        hacerRuido():void;
    }
}
