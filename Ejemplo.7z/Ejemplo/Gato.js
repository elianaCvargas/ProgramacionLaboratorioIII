///<reference path="./Animal.ts" />
var Mascota;
(function (Mascota) {
    var Gato = /** @class */ (function () {
        function Gato(nombre) {
            this.nombre = nombre;
        }
        Gato.prototype.hacerRuido = function () {
            console.log("miau!!!");
        };
        return Gato;
    }());
    Mascota.Gato = Gato;
})(Mascota || (Mascota = {}));
