/// <reference path="./Animal.ts" />
/// <reference path="./Perro.ts" />
/// <reference path="./Gato.ts" />
var Ejemplo;
(function (Ejemplo) {
    var Programa = /** @class */ (function () {
        function Programa() {
        }
        //function hablar(a:Animal){ function cuando esta dentro de la clase no es necesario 
        Programa.hablar = function (a) {
            console.log(a.nombre);
            a.hacerRuido();
        };
        Programa.accionar = function () {
            var perro = new Mascota.Perro("Timmy");
            var gato = new Mascota.Gato("Michi");
            var animales = new Array();
            animales.push(perro);
            animales.push(gato);
            animales.forEach(Programa.hablar);
        };
        Programa.crearMascota = function () {
            if ($("#dog").is(":checked")) {
                alert("checked");
            }
        };
        return Programa;
    }());
    Ejemplo.Programa = Programa;
})(Ejemplo || (Ejemplo = {}));
