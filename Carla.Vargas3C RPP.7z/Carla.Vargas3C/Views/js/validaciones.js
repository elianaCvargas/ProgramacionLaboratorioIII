
function validar(e) {
    borrarError();
    var retorno = true;
    if (!validaNombre())  {
        $("#nombre").addClass('error');
        retorno =  validaNombre();
    } 
    if(!validaApellido())
    {
            $("#apellido").addClass('error');
            retorno = validaApellido();   
    }
    if(!validarFecha())
    {
        $("#fecha").addClass('error');
        retorno = false;
    }
    if(retorno)
    {
        $("#nombre").addClass('ok');    
         $("#apellido").addClass('ok');
         $("#fecha").addClass('ok');
    }
    
    return retorno;
}

function validaNombre() {
    var retorno = true;
    var elemento = document.getElementById("nombre");
   
    if (elemento.validity.valueMissing) {
        $("#nombreRequerido").show();
        
        retorno = false;
    }
    else {
        if (elemento.value.length <= 3) {
           $("#nombreCorto").show();
            retorno = false;
        }
    }

    return retorno;
}
function validaApellido() {
    var retorno = true;
    var elemento = document.getElementById("apellido");
    if (elemento.validity.valueMissing) {
        $("#apellidoRequerido").show();
        retorno = false;
    }
    else {
        if (elemento.value.length <= 3) {
            $("#apellidoCorto").show();
            retorno = false;
        }
    }

    return retorno;
}


function error2(elemento, mensaje) {
    $("#mensajeError").innerHTML = mensaje;
    $(elemento).addClass('error');
    $(elemento).focus();
}

function borrarError() {
    var formulario = $("#formulario input").each(function (index, element) {
        $(element).removeClass();
    });
}

function validarFecha()
{
    var  dateString =document.getElementById("fecha").value;

    var date = Date.parse(dateString);
    if(date > Date.now())
    {
        return false;
        $("#fechaMenor").show();
    }
    return true;
   

    
    

}