var idActual = 0;
window.onload = function () {
    $.get("http://localhost:3000/traerAutos", function (autos) {
      var car=   JSON.parse(autos);
        
        listarAutos(car);
    }).fail(function () {
        alert("error al traer a las autos");
    });

    ocultarFormulario();
}

$(document).ready(function () {
    $("#edit").on('click', function () {
        editar();
    });
    $("#delete").on('click', function () {
        eliminar();
    });
    $("#add").on('click', function () {
        agregar();
    });
    $("#addNew").on('click', function () {
        enviarNuevo();
    });
    $.ajax
});

function enviarNuevo()
{
    
    var id = $('table tr:last').attr('id'); 
    
    var nombre = $("#nombre").val();
    var modelo = $("#modelo").val();
    var colorP = $("#color").val();

    var auto =
    {
        car_make: nombre,
        model_year: modelo,
        color: colorP,
     
    };
   //var obj =JSON.stringify(auto)
    enviarDatosPOST("agregar", auto);
    mostrarAnimacion(); 

   
}
function mostrarAnimacion()
{
    $("#formularioPop").addClass('opacidadForm');
    $("#cssload").show();
}

function agregar()
{
    $("#delete").hide();
    $("#edit").hide();
    $("#formularioPop").show();
    

}
function imageIsLoaded(e, id) {
    $("#file-input").css("color", "green");
    //$('#image_preview').css("display", "block");
    $('#image' + id).attr('src', e.target.result);

    var files = $('#file-upload-' + id);
    var imageParam = 
    {
        file: e.target.result,
        id: id
    }

    subirImagen('subirImagen',imageParam);
    

};





function listarAutos(autos) {
    if (autos.length != 0) {

        var i = 0;
        autos.forEach(function (auto) {
            i++;
            idActual = i;
            var row =
                "<tr ondblclick='verAuto(" + idActual +")'>" +
                "<td id = 'numero'>" + i.toString() + "</td>" +
                "<td id = 'nombre_" + i + "'>" + auto.car_make.toString() + "</td>" +
                "<td id = 'modelo_" + i + "'>" + auto.model_year.toString() + "</td>" +
                "<td id = 'color_" + i + "'>" + auto.color.toString() + "</td>" +           
                "</tr>";
            $("#autosTable").append(row);

            // Se coloca aquí porque se genera los input file en este momento y no al cargar el documento
            $("#file-upload-" + auto.id).change(function () {
                //$("#message").empty(); // To remove the previous error message
                // Se obtiene la tercer palabra por guion, que es el número (file-input-1)
                var id = this.id.split('-')[2];
                var file = this.files[0];
                var imagefile = file.type;
                var match = ["image/jpeg", "image/png", "image/jpg"];
                if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
                    $('#previewing').attr('src', 'noimage.png');
                    //$("#message").html("<p id='error'>Please Select A valid Image File</p>" + "<h4>Note</h4>" + "<span id='error_message'>Only jpeg, jpg and png Images type allowed</span>");
                    return false;
                }
                else {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        imageIsLoaded(e, id);
                    };
                    reader.readAsDataURL(this.files[0]);
                }
            });


            //finforeach
        }
    );
    }
    else {
        var row = "<tr><td colspan = 7>No se encontró datos</td></tr>";
        $("#tablaAutos").append(row);
    }
}

function ocultarFormulario(obj) {
    $("#formularioPop").hide();
    $("#cssload").hide();
    $("#nombreRequerido").hide();
    $("#apellidoRequerido").hide();
    $("#nombreCorto").hide();
    $("#apellidoCorto").hide();
    $("#loader").hide();
    $("#fechaMenor").hide();
}

function verAuto(indice) {

    var nombre = document.getElementById("nombre_" + indice).innerText;
    var modelo = document.getElementById("modelo_" + indice).innerText;
    var color = document.getElementById("color_" + indice).innerText;
    
    var nombreIn = document.getElementById("nombre");
    nombreIn.value = nombre;
    var modeloIn = document.getElementById("modelo");
    modeloIn.value = modelo;
    var colorIn = document.getElementById("color");
    colorIn.value = color;
    
    idActual = indice;
    document.getElementById("formularioPop").style.display = "block";
}

function editar() {

  //  if (validar()) {

        var nombre = $("#nombre").val();
        var modelo = $("#modelo").val();
        var colorP = $("#color").val();

        var auto =
        {
            car_make: nombre,
            model_year: modelo,
            color: colorP,
         
        };
       //var obj =JSON.stringify(auto)
        enviarDatosPOST("modificar", auto);

        $("#loader").show();
        $("#boxData").addClass("edit");
    //}

}

function eliminar() {
    var respuesta = confirm("Seguro que desea eliminar este registro?");
    var id = {
        "id": idActual
    };
    if (respuesta) {
        enviarDatosPOST("eliminar", id);
    }


}


function agregarId() {
    g = document.createElement('div');
    g.setAttribute("id", "Div1");
}

function adjuntarImagen(id) {
    alert("Falta!");

}

function animarBtnAdjuntar(id) {



    var adj = $('#btnAdjuntar_' + id);
    adj.toggleClass('abrir');
    adj.css({ "-webkit-transform": "translateX(100px)", "transition": "all 0.3s" });
}



$("#btnAdjuntar").click(function () {
    $("#btnAdjuntar").toggleClass("abrir");
});


$(document).ready(function () {
    $("tbody tr").on('dblclick', function () {
        // $('.selected').removeClass('selected');
        // $(this).addClass("selected");
        // var product = $('.p',this).html();
        // var infRate =$('.i',this).html();
        // var note =$('.n',this).html();
        alert("sarasa");
    });

});